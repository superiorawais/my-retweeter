<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Retweeter extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('main_model');
        $this->check();
    }
    
    public function check(){
        if($this->session->userdata('logged') == null){
            redirect('main/login');
        }
    }
    
    public function index(){
        $data['retweeter'] = $this->main_model->get_retweeter();
        $this->load->view('header');
        $this->load->view('retweeter/list',$data);
        $this->load->view('footer');
    }

    public function add() {
        $this->load->library('tweet');
        $this->tweet->enable_debug(TRUE);
        if (!$this->tweet->logged_in()) {
            $_access_token = '49005834-EMB6l88jNU6Z4S1ShQoxuOKE0CYmvfQdcjz5z3PgF';
            $_secret_access_token = '3LvLVDnTSISF18LHMKdkZkANRnleNl4BDWFVt4S3Zw';
            $tokens = array('oauth_token' => $_access_token, 'oauth_token_secret' => $_secret_access_token);
            //$this->tweet->set_tokens($tokens);
            $this->tweet->set_callback(site_url('retweeter/auth'));
            $this->tweet->login();
        }else{
            
        }


        /*
          $this->load->view('header');
          $this->load->view('retweeter/add');
          $this->load->view('footer');
         */
    }

    function auth() {
        $tokens = $this->tweet->get_tokens();

        // $user = $this->tweet->call('get', 'account/verify_credentiaaaaaaaaals');
        // 
        // Will throw an error with a stacktrace.

        $user = $this->tweet->call('get', 'account/verify_credentials');
        var_dump($user);

        $friendship = $this->tweet->call('get', 'friendships/show', array('source_screen_name' => $user->screen_name, 'target_screen_name' => 'elliothaughin'));
        var_dump($friendship);

        if ($friendship->relationship->target->following === FALSE) {
            $this->tweet->call('post', 'friendships/create', array('screen_name' => $user->screen_name, 'follow' => TRUE));
        }

        $this->tweet->call('post', 'statuses/update', array('status' => 'Testing #CodeIgniter Twitter library by @elliothaughin - http://bit.ly/grHmua'));

        $options = array(
            'count' => 10,
            'page' => 2,
            'include_entities' => 1
        );

        $timeline = $this->tweet->call('get', 'statuses/home_timeline');

        var_dump($timeline);
    }
}
?>