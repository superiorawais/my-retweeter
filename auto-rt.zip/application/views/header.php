<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <title>Auto Retweet</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <link rel="icon" type="image/png" href="images/favicon.png"/> 
        <link rel="stylesheet" href="<?php echo base_url(); ?>script/css/default.css" />
        <?php if (isset($css)){foreach($css as $value){?>
            <link rel="stylesheet" href="<?php echo base_url(); ?>script/css/<?php echo $value;?>.css" />
        <?php }}?>
        <script type="text/javascript">var base_url="<?php echo base_url();?>";</script>
        <script type="text/javascript" src="<?php echo base_url();?>script/js/jquery-1.7.1.min.js"></script>
    </head>
    <body>
        <div id="main-con">
            <div id="header">

            </div>
        </div>