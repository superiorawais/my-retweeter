<script type="text/javascript" src="<?php echo base_url();?>script/js/retweeter.js"></script>
<div id="retweeter-list">
    <div class="content-box"><!-- Start Content Box -->
        <div class="content-box-header">
            <h3>Add Retweeter Account</h3>
            <div class="clear"></div>
        </div> <!-- End .content-box-header -->
        <div class="content-box-content">
            <div id="tab1" class="tab-content default-tab" style="display: block;"> <!-- This is the target div. id must match the href of this div's tab -->
                <?php if($this->session->flashdata('rn_add')):?>
                <div class="notification png_bg <?php echo $this->session->flashdata('rn_add');?>">
                    <a class="close" href="#">
                        <img alt="close" title="Close this notification" src="<?php echo base_url(); ?>script/images/cross_grey_small.png" />
                    </a>
                    <div>
                        This is a Content Box. You can put whatever you want in it. By the way, you can close this notification with the top-right cross.
                    </div>
                </div>
                <?php endif;?>
            </div>     
        </div> <!-- End .content-box-content -->
    </div>
</div>