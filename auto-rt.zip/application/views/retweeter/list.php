<script type="text/javascript" src="<?php echo base_url();?>script/js/retweeter.js"></script>
<div id="retweeter-list">
    <div class="content-box"><!-- Start Content Box -->
        <div class="content-box-header">
            <h3>Retweeter Account List</h3>
            <div class="clear"></div>
        </div> <!-- End .content-box-header -->
        <div class="content-box-content">
            <div id="tab1" class="tab-content default-tab" style="display: block;"> <!-- This is the target div. id must match the href of this div's tab -->
                <div class="notification error png_bg">
                    <a class="close" href="#">
                        <img alt="close" title="Close this notification" src="<?php echo base_url(); ?>script/images/cross_grey_small.png" />
                    </a>
                    <div>
                        This is a Content Box. You can put whatever you want in it. By the way, you can close this notification with the top-right cross.
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th class="th-no">No</th>
                            <th>Account</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <td colspan="6">
                                <div class="add">
                                    <a title="First Page" href="<?php echo base_url();?>retweeter/add">Add Account</a>
                                </div>
                                <div class="pagination">
                                    <a title="First Page" href="#">« First</a><a title="Previous Page" href="#">« Previous</a>
                                    <a title="1" class="number" href="#">1</a>
                                    <a title="2" class="number" href="#">2</a>
                                    <a title="3" class="number current" href="#">3</a>
                                    <a title="4" class="number" href="#">4</a>
                                    <a title="Next Page" href="#">Next »</a><a title="Last Page" href="#">Last »</a>
                                </div> <!-- End .pagination -->
                                <div class="clear"></div>
                            </td>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $i=0;?>
                        <?php foreach ($retweeter->result() as $account): ?>
                            <tr <?php echo(($i % 2) == 0) ? 'class="alt-row"' : ''; ?>>
                                <td class="td-no"><?php echo $i + 1; ?></td>
                                <td><?php echo $account->username;?></td>
                                <td>
                                    <?php if($account->status==1):?>
                                    <a title="title" href="#" class="active-account">
                                        Enabled
                                    </a>
                                    <?php else:?>
                                    <a title="title" href="#" class="inactive-account">
                                        Disabled
                                    </a>
                                    <?php endif;?>
                                </td>
                                <td>
                                    <!-- Icons -->
                                    <a title="Edit Account" href="#"><img alt="Edit Account" src="<?php echo base_url(); ?>script/images/pencil.png" /></a>
                                    <a title="Delete Account" href="#"><img alt="Delete Account" src="<?php echo base_url(); ?>script/images/cross.png" /></a> 
                                    <a title="Manage Source Account" href="#"><img alt="Manage Source Account" src="<?php echo base_url(); ?>script/images/hammer_screwdriver.png" /></a>
                                </td>
                            </tr>
                            <?php $i++;?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>     
        </div> <!-- End .content-box-content -->
    </div>
</div>