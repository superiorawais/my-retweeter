<?php

class Main_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }
    
    function check_login($input){
        $this->config->load('login');
        $username = $this->config->item('system_username');
        $password = $this->config->item('system_password');
        if(($input['username']==$username) && ($input['password']==$password)){
            return true;
        }else{
            return false;
        }
    }
    
    function get_retweeter(){
        return $this->db->get('retweeter');
    }
}