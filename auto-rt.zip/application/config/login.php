<?php

$config['system_username'] = "admin";
$config['system_password'] = "admin";
?>
