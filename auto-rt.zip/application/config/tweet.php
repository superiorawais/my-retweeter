<?php
$config['tweet_consumer_key'] = "ZZlSmwLk9YCdjXzWauWZg";
$config['tweet_consumer_secret'] = "IIi7oUPLo3yumxozDZgV1TOQwDtTRzTLMVqvwAqHcY";
?>